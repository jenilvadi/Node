const passport = require("passport");
const localst = require("passport-local").Strategy;
const schema = require("../model/schema");


passport.use("local", new localst({ usernameField: "email" },
    async (email, password, done) => {
        let admin = await schema.findOne({ email: email });

        if (admin) {
            if (admin.password == password) {
                return done(null, admin);
            } else {
                return done(null, false);
            }
        } else {
            return done(null, false);
        };
    }
));

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (userid, done) => {
    let admin = await schema.findById(userid);
    done(null, admin);
});

passport.checkAuthentication = (req, res, next) => {
    if (req.isAuthenticated()) {
        next();
    } else {
        res.redirect("/");
    }
}

passport.AuthenticatedUser = (req, res, next) => {
    if (req.isAuthenticated()) {
        res.locals.user = req.user;
    }
    next();
};


module.exports = passport;
