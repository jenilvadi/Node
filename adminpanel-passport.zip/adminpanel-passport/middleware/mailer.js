const nodemailer = require('nodemailer');

const transport = nodemailer.createTransport({

    service:"gmail",
    auth:{
        user : "sahilchangani1234@gmail.com",
        pass:"Password come from gmail",
        
    },
});

module.exports.sendMail = async (req, res) => {
    let maileoption = {
        from : "email",
        to : to,
        subject : "Your password reset otp",
        text : `Your otp is ${otp}`,
    };

    transport.sendMail(mailoptions,(err)=>{
        err ? console.log(err) : console.log("Mail sent");
    });

};