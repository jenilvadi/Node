const fs = require("fs");
const path = require("path");
const Admin = require("../model/schema");
const upload = require("../middleware/multer");


module.exports.loginData = (req,res)=>{
    res.render("login");
}

module.exports.userlogin = async(req,res)=>{
    req.flash("success","Login Successfully");
    res.redirect("/dashboard");   
}

module.exports.Logout = (req,res)=>{
    req.flash("success", "Logsout Successfully" || "changed");
    req.session.destroy();
    res.redirect("/");
}

module.exports.dashboard = (req, res) => {
    res.render("index");
};

module.exports.addAdmin = (req, res) => {
    res.render("addAdmin");
};

module.exports.addAdminData = async (req, res) => {
    req.body.img = req.file.path;
    req.body.hobby = Array.isArray(req.body.hobby) ? req.body.hobby : [req.body.hobby];
    await Admin.create(req.body).then((data) => {
        req.flash("success","Add Data Successfully");
        res.redirect("/dashboard");
    });
};

module.exports.viewAdmin = async (req, res) => {
    const data = await Admin.find({})
    res.render("viewAdmin", { data })
};

module.exports.deleteAdmin = async (req, res) => {
    await Admin.findByIdAndDelete(req.query.id).then((data) => {
        req.flash("success","Data Deleted Successfully");
        res.redirect("/dashboard");
    });
}

module.exports.dataFill = async (req, res) => {
    await Admin.findById(req.query.id).then((data) => {
        res.render("updateAdmin");
    });
}

module.exports.updateAdminPage = async (req, res) => {
    const data = await Admin.findById(req.query.id);
    res.render("updateAdmin", { data });
};

module.exports.updateAdmin = async (req, res) => {
    let img = "";
    let singleData = await Admin.findById(req.body.id);
    req.file ? img = req.file.path : img = singleData.img;
    req.file && fs.unlinkSync(singleData.img);
    req.body.image = img;
    req.body.hobby = Array.isArray(req.body.hobby) ? req.body.hobby : [req.body.hobby];
    let data = await Admin.findByIdAndUpdate(req.body.id, req.body);
    req.flash("success", "Data Updated Successfully");
    data && res.redirect("/viewAdmin");

};

module.exports.profile = (req, res) => {
    res.render("profile");
}

module.exports.changePass = (req, res) => {
    res.render("changePass");
}

module.exports.changePassword = async (req, res) => {
    let user = req.user;
    if(user.password == req.body.oldPass){
        if(req.body.oldPass != req.body.newPass){
            if(req.body.newPass == req.body.confirmPass){
                let admin = await Admin.findByIdAndUpdate(user.id, { password: req.body.newPass });
                req.flash("success", "Password Changed Successfully");
                admin && res.redirect("/logout");
            } else {
                req.flash("error", "New and confirm password do not match");
                res.redirect("/changePass");
            }
        } else {
            req.flash("error", "Old and new password are the same");
            res.redirect("/changePass");
        }
    } else {
        req.flash("error", "Old password is incorrect");
        res.redirect("/changePass");
    }
};

