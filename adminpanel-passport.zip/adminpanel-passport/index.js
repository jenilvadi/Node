const express = require("express");
const port = 1008;
const path = require("path");
const app = express();
const db = require("./config/db");
const passport = require("./middleware/passport");
const session = require("express-session");
const cookie = require("cookie-parser");
const flash = require("connect-flash");
const flashconnect = require("./middleware/flashconnect")

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use(cookie());

app.use(
    session({
        name: "local",
        secret: 'sahil',
        resave: true,
        saveUninitialized: false,
        cookie: { maxAge: 100 * 100 * 60 },
    })
);

app.use(passport.initialize());
app.use(passport.session());
app.use(passport.AuthenticatedUser);
app.use(flash());
app.use(flashconnect.setFlash);

app.use("/", require(".bin/route"));

app.listen(port, (err) => {
    if (err) console.log(err);
    else {
        console.log(`Sercer Started http://localhost:${port}`);
    }
})
