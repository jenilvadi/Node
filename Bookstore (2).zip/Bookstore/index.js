const express = require('express')
const port = 2003

const app = express()

const db = require('./confing/db');
const schema = require('./model/firstschema')

let Book = []
app.set('view engine','ejs')
app.use(express.urlencoded())

app.get('/', async(req,res)=>{
  let data = await schema.find({});
  res.render("index",{data});
})
app.post("/addData", async(req,res)=>{
    // console.log(req.body)
   await schema.create(req.body)
   .then(data=>{
    res.redirect("/");
   })


})
app.get("/deleteData",async(req,res)=>{
    // console.log(req.query.id)
    await schema.findByIdAndDelete(req.query.id).then((data)=>{
        res.redirect("/");
    });
  
});
app.get("/editData",async(req,res)=>{
    // console.log(req.query.id)
    let data = await schema.findById(req.query.id);
    res.redirect("edit",{data});
})
app.post("/updateData", async(req,res)=>{
   await schema.findByIdAndUpdate(req.body.id,req.body).then((data)=>{
    res.redirect("/");
   })
})

app.listen(port,(err)=>{
    err?console.log(err):console.log(`server started http://localhost:${port}/`)
})