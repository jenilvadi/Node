const { name } = require('ejs');
const mongoose = require('mongoose');
const schema = mongoose.Schema({
    image:{
        type:String,
        required:true,
    },
    book:{
        type:String,
        required:true,
    },
    author:{
        type:String,
        required:true,
    },
    price:{
        type:Number,
        required:true,
    },
    date:{
        type:String
        ,
        required:true,
    },

});


const firstschema = mongoose.model('Book',schema);

module.exports = firstschema;